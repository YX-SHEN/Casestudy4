// 4.3.cc - Multigrid Convergence Analysis (Corrected Version)

#include <iostream>
#include <vector>
#include <cmath>
#include <tuple>
#include <iomanip>
#include <chrono>
#include <fstream>
#include "case4all.h"

bool validate_params(int N, int max_level, double omega, int nu1, int nu2)
{
    if (N % (1 << max_level) != 0)
    {
        std::cerr << "Error: N must be divisible by 2^max_level.\n";
        return false;
    }
    if (omega <= 0.0 || omega > 2.0 || nu1 < 0 || nu2 < 0)
    {
        std::cerr << "Error: Invalid omega or smoothing steps.\n";
        return false;
    }
    return true;
}

// Run one V-cycle convergence test (with full iteration)
void run_vcycle_analysis(int N, int max_level)
{
    double h = 1.0 / (N + 1);
    double omega = 2.0 / 3.0;
    int nu1 = 2, nu2 = 2;
    double tol = 1e-6;
    int max_iter = 100;

    if (!validate_params(N, max_level, omega, nu1, nu2))
        return;

    // === Build matrix and RHS ===
    std::vector<SparseEntry> triplet;
    std::vector<double> rhs;
    init_mg_level(N, h, triplet, rhs);

    std::vector<int> row_ptr, col_idx;
    std::vector<double> val;
    triplet_to_csr(triplet, N * N, row_ptr, col_idx, val);

    std::vector<double> x(N * N, 0.0); // initial guess
    std::vector<double> r0;
    compute_residual(row_ptr, col_idx, val, rhs, x, r0);
    double norm0 = std::sqrt(dot(r0, r0));
    double res_norm = norm0;

    std::vector<double> residuals;
    residuals.push_back(norm0);

    auto t_start = std::chrono::steady_clock::now();

    int iter = 0;
    bool converged = false;

    while (res_norm > tol && iter < max_iter)
    {
        vcycle_algo1(row_ptr, col_idx, val, rhs, x, 0, max_level, nu1, nu2, omega, true);

        std::vector<double> r_curr;
        compute_residual(row_ptr, col_idx, val, rhs, x, r_curr);
        res_norm = std::sqrt(dot(r_curr, r_curr));
        residuals.push_back(res_norm);

        iter++;
        if (res_norm < tol)
        {
            converged = true;
            break;
        }
    }

    auto t_end = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double>(t_end - t_start).count();

    std::cout << "N = " << std::setw(4) << N
              << " | L = " << max_level
              << " | Iter = " << std::setw(5) << iter
              << " | Time = " << std::fixed << std::setprecision(6) << elapsed << " s"
              << " | Final Residual = " << std::scientific << res_norm
              << (converged ? "  ✓ Converged" : "  ✗ Not converged") << "\n";
    // === Write summary line to CSV log ===
    std::ofstream flog("summary_log.csv", std::ios::app); // append mode
    flog << N << "," << max_level << "," << iter << "," << elapsed << "," << res_norm << "\n";
    flog.close();
    // Save residuals to file
    std::ofstream fout("residuals_N" + std::to_string(N) + "_L" + std::to_string(max_level) + ".txt");
    for (size_t i = 0; i < residuals.size(); ++i)
        fout << i << " " << residuals[i] << "\n";
    fout.close();
}

int main()
{
    std::cout << "=== Part A: Fixed N = 128, Varying Lmax ===\n";
    int fixed_N = 128;
    for (int L = 2; L <= std::log2(fixed_N); ++L)
    {
        run_vcycle_analysis(fixed_N, L);
    }

    std::cout << "\n=== Part B: Fixed Lmax = 2, Varying N ===\n";
    int fixed_L = 2;
    for (int N : {16, 32, 64, 128, 256})
    {
        run_vcycle_analysis(N, fixed_L);
    }

    return 0;
}
// 4.2.cc - Recursive V-cycle Multigrid Solver (with CG option on coarsest)

#include <iostream>
#include <vector>
#include <cmath>
#include <tuple>
#include <iomanip>
#include <string>
#include "case4all.h"

bool validate_params(int N, int max_level, double omega, int nu1, int nu2) {
    if (N % (1 << max_level) != 0) {
        std::cerr << "Error: N must be divisible by 2^max_level for multigrid.\n";
        return false;
    }
    if (omega <= 0.0 || omega > 2.0) {
        std::cerr << "Error: omega must be in (0, 2] for weighted Jacobi.\n";
        return false;
    }
    if (nu1 < 0 || nu2 < 0) {
        std::cerr << "Error: nu1 and nu2 must be non-negative.\n";
        return false;
    }
    return true;
}

int main(int argc, char* argv[]) {
    // === Step 0: Handle optional flag --use-cg ===
    bool use_cg_on_coarsest = false;
    for (int i = 1; i < argc; ++i) {
        std::string arg(argv[i]);
        if (arg == "--use-cg") {
            use_cg_on_coarsest = true;
        }
    }

    // === Step 1: Parameters and Initialization ===
    int N = 8;
    double h = 1.0 / (N + 1);
    double omega = 2.0 / 3.0;
    int nu1 = 2, nu2 = 2;
    double tol = 1e-6;
    int max_iter = 50;
    int max_level = std::log2(N);

    if (!validate_params(N, max_level, omega, nu1, nu2)) return 1;

    // === Step 2: Build matrix A and RHS b ===
    std::vector<SparseEntry> triplet;
    std::vector<double> rhs;
    init_mg_level(N, h, triplet, rhs);

    std::vector<int> row_ptr, col_idx;
    std::vector<double> val;
    triplet_to_csr(triplet, N * N, row_ptr, col_idx, val);

    std::vector<double> x(N * N, 0.0);  // initial guess

    std::vector<double> r0;
    compute_residual(row_ptr, col_idx, val, rhs, x, r0);
    double norm0 = std::sqrt(dot(r0, r0));
    std::cout << "Initial residual: " << norm0 << "\n";

    // === Step 3: Multigrid Iteration ===
    int iter = 0;
    double res_norm = norm0;

    while (res_norm > tol && iter < max_iter) {
        std::vector<double> r_prev;
        compute_residual(row_ptr, col_idx, val, rhs, x, r_prev);
        double prev_norm = std::sqrt(dot(r_prev, r_prev));

        // Call recursive V-cycle with or without CG
        vcycle_algo1(row_ptr, col_idx, val, rhs, x,
                     0, max_level, nu1, nu2, omega,
                     use_cg_on_coarsest);

        std::vector<double> r_curr;
        compute_residual(row_ptr, col_idx, val, rhs, x, r_curr);
        res_norm = std::sqrt(dot(r_curr, r_curr));
        iter++;

        std::cout << "Iter " << iter << ": residual = " << res_norm << "\n";

        if (res_norm > prev_norm) {
            std::cerr << "Warning: residual increased (possible divergence).\n";
            break;
        }
    }

    if (res_norm <= tol) {
        std::cout << "Converged in " << iter << " iterations.\n";
    } else {
        std::cout << "Did not converge after " << iter << " iterations.\n";
    }

    return 0;
}
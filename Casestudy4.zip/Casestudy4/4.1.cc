#include <iostream>
#include <vector>
#include <cmath>
#include <tuple>
#include <iomanip>
#include "case4all.h"

int main() {
    int N = 8;                     // Grid size (N x N interior points), must be divisible by 2^L
    double h = 1.0 / (N + 1);      // Grid spacing

    // Construct sparse matrix A and RHS vector b using 5-point stencil
    std::vector<SparseEntry> triplet;
    std::vector<double> rhs;
    init_mg_level(N, h, triplet, rhs);

    // Convert triplet (COO) format to CSR format
    std::vector<int> row_ptr, col_idx;
    std::vector<double> val;
    triplet_to_csr(triplet, N * N, row_ptr, col_idx, val);

    // Initialize solution vector x with zeros
    std::vector<double> x(N * N, 0.0);

    // Compute initial residual norm
    std::vector<double> r0;
    compute_residual(row_ptr, col_idx, val, rhs, x, r0);
    double r0_norm = std::sqrt(dot(r0, r0));
    std::cout << "Initial residual norm: " << r0_norm << "\n";

    // Apply one V-cycle
    int max_level = std::log2(N);   // Maximum multigrid level (N must be power of 2)
    int nu1 = 2, nu2 = 2;           // Pre-/post-smoothing steps
    double omega = 2.0 / 3.0;       // Relaxation factor for Jacobi smoother

    vcycle(row_ptr, col_idx, val, rhs, x, 0, max_level, nu1, nu2, omega);

    // Compute residual norm after V-cycle
    std::vector<double> r1;
    compute_residual(row_ptr, col_idx, val, rhs, x, r1);
    double r1_norm = std::sqrt(dot(r1, r1));
    std::cout << "Residual norm after 1 V-cycle: " << r1_norm << "\n";

    return 0;
}


#include <iostream>
#include <vector>
#include <tuple>
#include <cmath>
#include <chrono>
#include <algorithm>
#include <iomanip>
#include <fstream>
#include "case4all.h"
#include <map>
// sparse matrix as (row, col, value)
// dense = too big & wasteful
using SparseEntry = std::tuple<int, int, double>;
std::map<int, std::tuple<std::vector<int>, std::vector<int>, std::vector<double>>> coarse_cache;
// exact solution: u = sin(π x) sin(π y)
// so RHS f = 2π² sin(πx) sin(πy)（3.1）
// RHS: f(x, y) = 2π² sin(πx) sin(πy)（3.2）
double source_term(double x, double y)
{
    return 2.0 * M_PI * M_PI * std::sin(M_PI * x) * std::sin(M_PI * y);
}
// Automatically calculate the maximum number of multiple grid layers
int compute_max_levels(int N)
{
    int levels = 0;
    while (N >= 8)
    {
        N /= 2;
        ++levels;
    }
    return levels - 1;
}

// Constructs matrix A_l and RHS b_l for MG level-l problem
// Poisson 2D: -Δu = f(x,y) on Ω = (0,1)^2, u = 0 on ∂Ω
// Discretized using 5-point central difference (symmetric FD) scheme:
// Δu(i,j) ≈ [u(i+1,j) + u(i-1,j) + u(i,j+1) + u(i,j-1) - 4u(i,j)] / h²
// Unknowns stored row-major: idx(i,j) = i*N + j, for 0 ≤ i,j < N
// Inputs:
//    N       : number of interior grid points per dimension (N×N total)
//    h       : grid spacing = 1 / (N+1)
// Outputs:
//    triplet : sparse matrix in (row, col, value) format (A_l)
//    rhs     : right-hand side vector b_l
void init_mg_level(int N, double h,
                   std::vector<std::tuple<int, int, double>> &triplet,
                   std::vector<double> &rhs)
{
    int total = N * N;
    triplet.clear();
    rhs.resize(total);

    const double h2inv = 1.0 / (h * h);
    const double eps = 1e-10; // offset to avoid sin(πx) = 0 due to rounding

    for (int row = 0; row < N; ++row)
    {
        for (int col = 0; col < N; ++col)
        {
            int idx = col + row * N;

            // Physical coordinates (x,y) shifted by +1 to skip boundary
            double x = (col + 1) * h + eps;
            double y = (row + 1) * h + eps;

            // Diagonal entry: 4/h²
            triplet.emplace_back(idx, idx, 4.0 * h2inv);

            // 4 neighbors: -1/h²
            auto add_neighbor = [&](int offset, bool valid)
            {
                if (valid)
                    triplet.emplace_back(idx, idx + offset, -1.0 * h2inv);
            };
            add_neighbor(-1, col > 0);     // left
            add_neighbor(+1, col < N - 1); // right
            add_neighbor(-N, row > 0);     // top
            add_neighbor(+N, row < N - 1); // bottom

            // RHS: f(x,y) = 2π² sin(πx) sin(πy)
            rhs[idx] = source_term(x, y);
        }
    }
}

// simple print to check small matrices
void debug_print(int grid_size, const std::vector<SparseEntry> &matrix, const std::vector<double> &rhs)
{
    std::cout << "Generated matrix entries:\n";
    for (const auto &[i, j, val] : matrix)
    {
        std::cout << "A[" << i << "," << j << "] = " << std::setw(10) << val << "\n";
    }

    std::cout << "\nRight-hand side vector:\n";
    for (int i = 0; i < grid_size; ++i)
    {
        for (int j = 0; j < grid_size; ++j)
        {
            int idx = j + i * grid_size;
            std::cout << std::setw(10) << rhs[idx] << " ";
        }
        std::cout << "\n";
    }
}

// convert (triplet) → CSR (row_ptr, col_idx, val)
void triplet_to_csr(const std::vector<SparseEntry> &triplet, int n,
                    std::vector<int> &row_ptr, std::vector<int> &col_idx, std::vector<double> &val)
{
    std::vector<std::vector<std::pair<int, double>>> rows(n);
    for (const auto &[i, j, v] : triplet)
        rows[i].emplace_back(j, v);

    row_ptr.clear();
    row_ptr.push_back(0);
    col_idx.clear();
    val.clear();

    for (int i = 0; i < n; ++i)
    {
        std::sort(rows[i].begin(), rows[i].end()); // optional sort by col
        for (const auto &[j, v] : rows[i])
        {
            col_idx.push_back(j);
            val.push_back(v);
        }
        row_ptr.push_back(static_cast<int>(col_idx.size()));
    }
}

// y = A * x using CSR
void sparse_matvec_csr(const std::vector<int> &row_ptr, const std::vector<int> &col_idx,
                       const std::vector<double> &val, const std::vector<double> &x, std::vector<double> &y)
{
    int n = row_ptr.size() - 1;
    y.assign(n, 0.0);
    for (int i = 0; i < n; ++i)
    {
        for (int k = row_ptr[i]; k < row_ptr[i + 1]; ++k)
        {
            y[i] += val[k] * x[col_idx[k]];
        }
    }
}

// dot product of two vectors
double dot(const std::vector<double> &a, const std::vector<double> &b)
{
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); ++i)
        sum += a[i] * b[i];
    return sum;
}

// Performs weighted Jacobi smoothing on Ax = b using CSR sparse matrix
// Solves approximately: A x ≈ b
// One sweep: xᵢ ← xᵢ + ω (bᵢ - Aᵢ·x) / Aᵢᵢ
// Inputs:
//    row_ptr, col_idx, val : CSR matrix A (size n × n)
//    b      : RHS vector b
//    x      : current solution guess (in-place update)
//    omega  : relaxation parameter (0 < ω ≤ 2), e.g. ω = 2/3
//    nu     : number of iterations (e.g., 2–5)
// Outputs:
//    x      : updated in-place after ν sweeps of weighted Jacobi
void jacobi_smoother(const std::vector<int> &row_ptr,
                     const std::vector<int> &col_idx,
                     const std::vector<double> &val,
                     const std::vector<double> &b,
                     std::vector<double> &x,
                     double omega,
                     int nu)
{
    int n = b.size();
    std::vector<double> x_new(n, 0.0);

    for (int iter = 0; iter < nu; ++iter)
    {
        for (int i = 0; i < n; ++i)
        {
            double diag = 0.0;
            double Ax_i = 0.0;
            for (int k = row_ptr[i]; k < row_ptr[i + 1]; ++k)
            {
                int j = col_idx[k];
                double a_ij = val[k];
                if (j == i)
                    diag = a_ij;
                else
                    Ax_i += a_ij * x[j];
            }
            x_new[i] = x[i] + omega * (b[i] - Ax_i - diag * x[i]) / diag;
        }

        x = x_new; // Update in-place for next iteration
    }
}

// Compute residual: r = b - A x
// Inputs:
//    A in CSR format: (row_ptr, col_idx, val)
//    b: right-hand side vector
//    x: current approximation
// Output:
//    r: residual vector
void compute_residual(const std::vector<int> &row_ptr,
                      const std::vector<int> &col_idx,
                      const std::vector<double> &val,
                      const std::vector<double> &b,
                      const std::vector<double> &x,
                      std::vector<double> &r)
{
    int n = b.size();
    std::vector<double> Ax(n, 0.0);

    // Compute A * x
    for (int i = 0; i < n; ++i)
    {
        for (int k = row_ptr[i]; k < row_ptr[i + 1]; ++k)
        {
            Ax[i] += val[k] * x[col_idx[k]];
        }
    }

    // r = b - Ax
    r.resize(n);
    for (int i = 0; i < n; ++i)
    {
        r[i] = b[i] - Ax[i];
    }
}

// Restrict fine-grid residual r_fine (N×N) to coarse-grid RHS b_coarse ((N/2)×(N/2))
// Uses full-weighting scheme (5-point stencil + diagonal averaging)
// Inputs:
//    r_fine : residual on fine grid (size N^2, N even)
//    N      : fine grid size (1D), total N^2 unknowns
// Output:
//    r_coarse : restricted residual on coarse grid (size (N/2)^2)
void restrict_full_weighting(const std::vector<double> &r_fine, int N,
                             std::vector<double> &r_coarse)
{
    int Nc = N / 2;
    r_coarse.assign(Nc * Nc, 0.0);

    auto idx = [N](int i, int j)
    { return i + j * N; };
    auto idx_c = [Nc](int i, int j)
    { return i + j * Nc; };

    for (int j = 0; j < Nc; ++j)
    {
        for (int i = 0; i < Nc; ++i)
        {
            int I = 2 * i;
            int J = 2 * j;

            double sum = 0.0;
            if (I < N && J < N)
            {
                sum += 4.0 * r_fine[idx(I, J)];
                if (I > 0)
                    sum += 2.0 * r_fine[idx(I - 1, J)];
                if (I + 1 < N)
                    sum += 2.0 * r_fine[idx(I + 1, J)];
                if (J > 0)
                    sum += 2.0 * r_fine[idx(I, J - 1)];
                if (J + 1 < N)
                    sum += 2.0 * r_fine[idx(I, J + 1)];

                if (I > 0 && J > 0)
                    sum += r_fine[idx(I - 1, J - 1)];
                if (I > 0 && J + 1 < N)
                    sum += r_fine[idx(I - 1, J + 1)];
                if (I + 1 < N && J > 0)
                    sum += r_fine[idx(I + 1, J - 1)];
                if (I + 1 < N && J + 1 < N)
                    sum += r_fine[idx(I + 1, J + 1)];
            }

            r_coarse[idx_c(i, j)] = sum / 16.0;
        }
    }
}

// Prolong coarse-grid correction (Nc×Nc) to fine-grid (2Nc×2Nc) using bilinear interpolation
// Inputs:
//    e_coarse : coarse grid correction (size Nc^2)
//    Nc       : coarse grid size (Nc = N / 2)
// Output:
//    e_fine   : interpolated fine-grid correction (size N^2)
void prolong_bilinear(const std::vector<double> &e_coarse, int Nc,
                      std::vector<double> &e_fine)
{
    int N = 2 * Nc;
    e_fine.assign(N * N, 0.0);

    auto idx_c = [Nc](int i, int j)
    { return i + j * Nc; };
    auto idx_f = [N](int i, int j)
    { return i + j * N; };

    for (int j = 0; j < Nc; ++j)
    {
        for (int i = 0; i < Nc; ++i)
        {
            double val = e_coarse[idx_c(i, j)];

            // Map to fine grid
            int I = 2 * i;
            int J = 2 * j;

            // 1. center
            e_fine[idx_f(I, J)] += val;

            // 2. east
            if (I + 1 < N)
                e_fine[idx_f(I + 1, J)] += 0.5 * val;

            // 3. north
            if (J + 1 < N)
                e_fine[idx_f(I, J + 1)] += 0.5 * val;

            // 4. northeast
            if (I + 1 < N && J + 1 < N)
                e_fine[idx_f(I + 1, J + 1)] += 0.25 * val;
        }
    }
}

// Multigrid V-cycle recursion
// Inputs:
//   row_ptr, col_idx, val : CSR matrix A_l (size n x n)
//   b     : RHS vector b_l (size n)
//   x     : initial guess for solution (in-place updated)
//   level : current multigrid level (0 = finest, L = coarsest)
//   max_level : maximum MG level (e.g., log2(N) - 1)
//   nu1   : pre-smoothing steps
//   nu2   : post-smoothing steps
//   omega : relaxation factor (e.g., 2/3)
void vcycle(const std::vector<int> &row_ptr,
            const std::vector<int> &col_idx,
            const std::vector<double> &val,
            const std::vector<double> &b,
            std::vector<double> &x,
            int level,
            int max_level,
            int nu1,
            int nu2,
            double omega)
{
    int N = std::sqrt(b.size()); // current grid size (N x N)
    if (level == max_level)
    {
        // Coarsest level: solve exactly (e.g., few CG or smoother)
        jacobi_smoother(row_ptr, col_idx, val, b, x, omega, 20);
        return;
    }

    // Pre-smoothing: ν₁ Jacobi steps
    jacobi_smoother(row_ptr, col_idx, val, b, x, omega, nu1);

    // Compute residual: r = b - A x
    std::vector<double> r;
    compute_residual(row_ptr, col_idx, val, b, x, r);

    // Restrict residual to coarse grid
    std::vector<double> r_coarse;
    restrict_full_weighting(r, N, r_coarse);

    // Build coarse grid matrix A_{l+1} and RHS b_{l+1}
    int Nc = N / 2;
    double h_coarse = 1.0 / (Nc + 1);
    std::vector<SparseEntry> triplet_coarse;
    std::vector<double> b_coarse;
    init_mg_level(Nc, h_coarse, triplet_coarse, b_coarse); // reuse source_term

    std::vector<int> rp_c, ci_c;
    std::vector<double> val_c;
    triplet_to_csr(triplet_coarse, Nc * Nc, rp_c, ci_c, val_c);

    // RHS becomes restricted residual
    b_coarse = r_coarse;
    std::vector<double> e_coarse(Nc * Nc, 0.0);

    // Recursive call: e_coarse ← V-cycle on coarse level
    vcycle(rp_c, ci_c, val_c, b_coarse, e_coarse, level + 1, max_level, nu1, nu2, omega);

    // Prolong correction and apply: x ← x + prolong(e_coarse)
    std::vector<double> e_fine;
    prolong_bilinear(e_coarse, Nc, e_fine);
    for (size_t i = 0; i < x.size(); ++i)
    {
        x[i] += e_fine[i];
    }

    // Post-smoothing: ν₂ Jacobi steps
    jacobi_smoother(row_ptr, col_idx, val, b, x, omega, nu2);
}

void solve_coarsest_level(const std::vector<double> &b,
                          std::vector<double> &x,
                          int Nc,
                          double omega)
{
    if (coarse_cache.count(Nc * Nc) == 0)
    {
        std::vector<SparseEntry> triplet;
        double h = 1.0 / (Nc + 1);
        std::vector<double> dummy_rhs;
        init_mg_level(Nc, h, triplet, dummy_rhs);
        std::vector<int> rp, ci;
        std::vector<double> val;
        triplet_to_csr(triplet, Nc * Nc, rp, ci, val);
        coarse_cache[Nc * Nc] = std::make_tuple(rp, ci, val);
    }
    auto &[row_ptr, col_idx, val] = coarse_cache[Nc * Nc];
    // Solve A x = b using Jacobi for now
    jacobi_smoother(row_ptr, col_idx, val, b, x, omega, 20);
}

void solve_coarsest_level_cg(const std::vector<double> &b,
                             std::vector<double> &x,
                             int Nc,
                             double omega,
                             int max_iter,
                             double tol)
{
    int n = Nc * Nc;

    if (coarse_cache.count(n) == 0)
    {
        std::vector<SparseEntry> triplet;
        double h = 1.0 / (Nc + 1);
        std::vector<double> dummy_rhs;
        init_mg_level(Nc, h, triplet, dummy_rhs);
        std::vector<int> rp, ci;
        std::vector<double> val;
        triplet_to_csr(triplet, n, rp, ci, val);
        coarse_cache[n] = std::make_tuple(rp, ci, val);
    }

    const auto &[row_ptr, col_idx, val] = coarse_cache[n];

    // Initialize
    x.assign(n, 0.0);
    std::vector<double> r = b;
    std::vector<double> p = r;
    std::vector<double> Ap(n, 0.0);

    double r_dot_r = dot(r, r);
    if (r_dot_r < tol * tol)
        return;

    for (int iter = 0; iter < max_iter; ++iter)
    {
        sparse_matvec_csr(row_ptr, col_idx, val, p, Ap);
        double alpha = r_dot_r / dot(p, Ap);

        for (int i = 0; i < n; ++i)
            x[i] += alpha * p[i];
        for (int i = 0; i < n; ++i)
            r[i] -= alpha * Ap[i];

        double r_dot_r_new = dot(r, r);
        if (std::sqrt(r_dot_r_new) < tol)
            break;

        double beta = r_dot_r_new / r_dot_r;
        for (int i = 0; i < n; ++i)
            p[i] = r[i] + beta * p[i];
        r_dot_r = r_dot_r_new;
    }
}

void vcycle_algo1(const std::vector<int> &row_ptr,
                  const std::vector<int> &col_idx,
                  const std::vector<double> &val,
                  const std::vector<double> &b,
                  std::vector<double> &x,
                  int level,
                  int max_level,
                  int nu1,
                  int nu2,
                  double omega,
                  bool use_cg_on_coarsest)
{
    int N = std::sqrt(b.size()); // current grid size N x N

    // Step 1: Pre-smoothing
    jacobi_smoother(row_ptr, col_idx, val, b, x, omega, nu1);

    // Step 2: Compute residual r = b - A*x
    std::vector<double> r;
    compute_residual(row_ptr, col_idx, val, b, x, r);

    // Step 3: Restrict residual to coarse grid
    std::vector<double> r_coarse;
    restrict_full_weighting(r, N, r_coarse);

    // Step 4: Terminate if coarsest level
    if (level == max_level)
    {
        int Nc = std::sqrt(b.size());
        std::vector<double> e_coarse(Nc * Nc, 0.0);
        if (use_cg_on_coarsest)
        {
            solve_coarsest_level_cg(b, e_coarse, Nc, omega, 100, 1e-8);
        }
        else
        {
            solve_coarsest_level(b, e_coarse, Nc, omega);
        }
        x = e_coarse;
        return;
    }

    // Step 5: Build A_{l+1}
    int Nc = N / 2;
    double h_coarse = 1.0 / (Nc + 1);
    std::vector<SparseEntry> triplet_coarse;
    std::vector<double> b_coarse;
    init_mg_level(Nc, h_coarse, triplet_coarse, b_coarse); // we will overwrite b_coarse anyway
    std::vector<int> rp_c, ci_c;
    std::vector<double> val_c;
    triplet_to_csr(triplet_coarse, Nc * Nc, rp_c, ci_c, val_c);

    // Step 6: Set b_{l+1} = r_coarse
    b_coarse = r_coarse;

    // Step 7: Initialize e_{l+1} = 0
    std::vector<double> e_coarse(Nc * Nc, 0.0);

    // Step 8: Recursive call
    vcycle_algo1(rp_c, ci_c, val_c, b_coarse, e_coarse, level + 1, max_level, nu1, nu2, omega, use_cg_on_coarsest);

    // Step 9: Prolong and correct x ← x + P * e_coarse
    std::vector<double> e_fine;
    prolong_bilinear(e_coarse, Nc, e_fine);
    for (size_t i = 0; i < x.size(); ++i)
    {
        x[i] += e_fine[i];
    }

    // Step 10: Post-smoothing
    jacobi_smoother(row_ptr, col_idx, val, b, x, omega, nu2);
}


#pragma once
#include <vector>
#include <tuple>
#include <string>

// Sparse matrix format: (row, col, value)
using SparseEntry = std::tuple<int, int, double>;

int compute_max_levels(int N);

// Right-hand side function: f(x, y) = 2π² sin(πx) sin(πy)
double source_term(double x, double y);

// Initialize one MG level: build matrix A_l and RHS b_l
void init_mg_level(int N, double h,
                   std::vector<SparseEntry> &triplet,
                   std::vector<double> &rhs);

// Convert (i,j,val) triplet format → CSR format
void triplet_to_csr(const std::vector<SparseEntry> &triplet, int n,
                    std::vector<int> &row_ptr,
                    std::vector<int> &col_idx,
                    std::vector<double> &val);

// CSR SpMV: y = A * x
void sparse_matvec_csr(const std::vector<int> &row_ptr,
                       const std::vector<int> &col_idx,
                       const std::vector<double> &val,
                       const std::vector<double> &x,
                       std::vector<double> &y);
void compute_residual(const std::vector<int> &row_ptr,
                      const std::vector<int> &col_idx,
                      const std::vector<double> &val,
                      const std::vector<double> &b,
                      const std::vector<double> &x,
                      std::vector<double> &r);
// Vector dot product: ⟨a, b⟩
double dot(const std::vector<double> &a, const std::vector<double> &b);

void prolong_bilinear(const std::vector<double> &e_coarse, int Nc,
                      std::vector<double> &e_fine);
// Weighted Jacobi smoother: ν steps
void jacobi_smoother(const std::vector<int> &row_ptr,
                     const std::vector<int> &col_idx,
                     const std::vector<double> &val,
                     const std::vector<double> &b,
                     std::vector<double> &x,
                     double omega,
                     int nu);

void vcycle(const std::vector<int> &row_ptr,
            const std::vector<int> &col_idx,
            const std::vector<double> &val,
            const std::vector<double> &b,
            std::vector<double> &x,
            int level,
            int max_level,
            int nu1,
            int nu2,
            double omega);
void vcycle_algo1(const std::vector<int> &row_ptr,
                  const std::vector<int> &col_idx,
                  const std::vector<double> &val,
                  const std::vector<double> &b,
                  std::vector<double> &x,
                  int level,
                  int max_level,
                  int nu1,
                  int nu2,
                  double omega,
                  bool use_cg_on_coarsest);
void restrict_full_weighting(const std::vector<double> &r_fine, int N,
                             std::vector<double> &r_coarse);
void solve_coarsest_level(const std::vector<double> &b,
                          std::vector<double> &x,
                          int N,
                          double omega);

void solve_coarsest_level_cg(const std::vector<double> &b,
                             std::vector<double> &x,
                             int Nc,
                             double omega,
                             int max_iter = 100,
                             double tol = 1e-8);

// Debug print: matrix entries & RHS (small size only)
void debug_print(int grid_size,
                 const std::vector<SparseEntry> &matrix,
                 const std::vector<double> &rhs);
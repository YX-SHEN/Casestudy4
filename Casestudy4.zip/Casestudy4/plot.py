import matplotlib.pyplot as plt
import numpy as np
import os
import re
import pandas as pd

plt.style.use("seaborn-v0_8-muted")


# === Part A: fixed N=128, varying L ===
def plot_part_a():
    files = sorted([f for f in os.listdir() if re.match(r'residuals_N128_L\d+\.txt', f)])
    if not files:
        print("[Warning] No residuals files found for Part A.")
        return

    plt.figure(figsize=(8, 6))
    for fname in files:
        data = np.loadtxt(fname)
        iter = data[:, 0]
        residual = data[:, 1]
        L = re.search(r'L(\d+)', fname).group(1)
        plt.semilogy(iter, residual, label=f"Lmax = {L}")

    plt.xlabel("Iteration")
    plt.ylabel("Residual Norm ‖r‖")
    plt.title("Part A: Convergence for N=128, varying Lmax")
    plt.grid(True, which="both", ls="--", alpha=0.4)
    plt.legend()
    plt.tight_layout()
    # plt.savefig("partA_convergence.pdf")
    plt.savefig("partA_convergence.png", dpi=300)
    plt.show()


# === Part B: fixed L=2, varying N ===
def plot_part_b():
    files = sorted([f for f in os.listdir() if re.match(r'residuals_N\d+_L2\.txt', f)])
    if not files:
        print("[Warning] No residuals files found for Part B.")
        return

    plt.figure(figsize=(8, 6))
    for fname in files:
        data = np.loadtxt(fname)
        iter = data[:, 0]
        residual = data[:, 1]
        N = re.search(r'N(\d+)_L2', fname).group(1)
        plt.semilogy(iter, residual, label=f"N = {N}")

    plt.xlabel("Iteration")
    plt.ylabel("Residual Norm ‖r‖")
    plt.title("Part B: Convergence for Lmax=2, varying N")
    plt.grid(True, which="both", ls="--", alpha=0.4)
    plt.legend()
    plt.tight_layout()
    # plt.savefig("partB_convergence.pdf")
    plt.savefig("partB_convergence.png", dpi=300)
    plt.show()


# === Optional: Plot summary from CSV ===
def plot_summary_csv():
    if not os.path.exists("summary_log.csv"):
        print("[Info] summary_log.csv not found. Skipping summary plot.")
        return

    df = pd.read_csv("summary_log.csv", header=None,
                     names=["N", "L", "Iter", "Time", "FinalResidual"])

    # Part A: fixed N=128, varying L
    df_part_a = df[df["N"] == 128]
    plt.figure(figsize=(8, 5))
    plt.plot(df_part_a["L"], df_part_a["Iter"], "o-", label="Iterations")
    plt.plot(df_part_a["L"], df_part_a["FinalResidual"], "s--", label="Final Residual")
    plt.xlabel("Lmax")
    plt.title("Part A Summary: Iterations vs Residuals")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    # plt.savefig("partA_summary.pdf")
    plt.savefig("partA_summary.png", dpi=300)
    plt.show()

    # Part B: fixed L=2, varying N
    df_part_b = df[df["L"] == 2]
    plt.figure(figsize=(8, 5))
    plt.plot(df_part_b["N"], df_part_b["Iter"], "o-", label="Iterations")
    plt.plot(df_part_b["N"], df_part_b["FinalResidual"], "s--", label="Final Residual")
    plt.xlabel("Grid Size N")
    plt.title("Part B Summary: Iterations vs Residuals")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    # plt.savefig("partB_summary.pdf")
    plt.savefig("partB_summary.png", dpi=300)
    plt.show()


if __name__ == "__main__":
    plot_part_a()
    plot_part_b()
    plot_summary_csv()